package edu.temple.paletteactivity2;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by tylermast on 2/9/18.
 */

public class CustomAdapter extends BaseAdapter{

    Activity activity;
    String[] colors;
    LayoutInflater inflater;


    public CustomAdapter(Activity activity, String[] colors){
        this.activity=activity;
        this.colors=colors;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount(){
        return colors.length;
    }

    public long getItemId(int i){
        return 0;
    }

    public Object getItem(int i){
        return null;
    }

    public View getView(int i, View view, ViewGroup viewGroup){

        View row = inflater.inflate(R.layout.spinner_row,null);

        TextView textView = (TextView) row.findViewById(R.id.title);
        textView.setText(colors[i]);
        textView.setBackgroundColor(Color.parseColor(colors[i]));
        return row;
    }

}
