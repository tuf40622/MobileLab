package edu.temple.signupform;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FormActivity extends Activity {

    EditText editText;
    Button button;
    String GetEditText;
    String CompareText;
    int n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        Button myButton = (Button) findViewById(R.id.myButton);
        final EditText name = (EditText) findViewById(R.id.name);
        final EditText email = (EditText) findViewById(R.id.email);
        final EditText password = (EditText) findViewById(R.id.password);
        final EditText passwordConf = (EditText) findViewById(R.id.passwordC);


        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n=1;
                GetEditText = name.getText().toString();
                if(TextUtils.isEmpty(GetEditText)){
                    Toast.makeText(FormActivity.this, "Must Enter Name", Toast.LENGTH_SHORT).show();
                    n=0;
                }

                GetEditText = email.getText().toString();
                if (TextUtils.isEmpty(GetEditText)&&n==1){
                    Toast.makeText(FormActivity.this, "Must Enter Email", Toast.LENGTH_SHORT).show();
                    n=0;
                }

                GetEditText = password.getText().toString();
                if(TextUtils.isEmpty(GetEditText) && n==1){
                    Toast.makeText(FormActivity.this, "Must Enter Password", Toast.LENGTH_SHORT).show();
                    n=0;
                }

                GetEditText = passwordConf.getText().toString();
                if(TextUtils.isEmpty(GetEditText) && n==1){
                    Toast.makeText(FormActivity.this, "Must Comfirm Password", Toast.LENGTH_SHORT).show();
                    n=0;
                }


                CompareText = password.getText().toString();
                if(n==1){
                    if(CompareText.equals(GetEditText)) {
                        Toast.makeText(FormActivity.this, "Your info has been saved", Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(FormActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();

                }


            }
        });


    }

}
